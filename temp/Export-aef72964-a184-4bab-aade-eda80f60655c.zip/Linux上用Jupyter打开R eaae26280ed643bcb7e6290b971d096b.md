# Linux上用Jupyter打开R

Jupyter默认运行Python内核。现在尝试配置运行R内核（谁叫rStudio不给我权限呢）

**Table of content**

## Installing and configuring

- Open R in Linux console, install the following packages (would be better if we install them one-by-one):

```r
install.packages(c("'repr', 'IRdisplay', 'evaluate', 'crayon', 
'pbdZMQ', 'devtools', 'uuid', 'digest','IRkernel'))
IRkernel::installspec()  # to register the kernel in the current R installation
```

- Then we can begin running Jupyter Notebook.

## Running R in Jupyter Notebook

- In the Linux Console, we run `jupyter notebook &`
- Open a Local Console, run `ssh -L 1234:localhost:8888 Huanga@202.116.90.56 -p 22`to connect to the remote linux server. (1234 is set by ourselves, `8888`is default by jupyter notebook, and the remains are info of remote server.) May need to enter the security code.
- Launch a webpage: [http://127.0.0.1:1234/](http://127.0.0.1:1234/notebooks/Untitled1.ipynb), while 127.0.0.1 is the local address.
- A home page will show

![Untitled](Linux%E4%B8%8A%E7%94%A8Jupyter%E6%89%93%E5%BC%80R%20eaae26280ed643bcb7e6290b971d096b/Untitled.png)

(You may need to enter a code here too. Mine is 123456)

- Click "New", and in the pull-down we choose "R" ( as the kernel of our new file script). Then everything is done!

## Problem shooting

- How it display
    
    Some of them will be shown in the notebook, while others will be in the Linux Console (especially some long procedures and some ERRORs)
    
- An error during stalling packages: `libicui18n.so.58`: `No such file or dictionary.`
    
    ```bash
    Error : /tmp/Rtmp7cfZnR/R.INSTALL291a47a178675/xml2/man/read_xml.Rd:47: 无法载入共享目标对象‘/opt/microsoft/ropen/3.5.3/lib64/R/library/xml2/libs/xml2.so’：:
      libicui18n.so.58: 无法打开共享对象文件: 没有那个文件或目录
    ERROR: installing Rd objects failed for package ‘xml2’
    * removing ‘/opt/microsoft/ropen/3.5.3/lib64/R/library/xml2’
    ERROR: dependency ‘xml2’ is not available for package ‘rvest’
    * removing ‘/opt/microsoft/ropen/3.5.3/lib64/R/library/rvest’
    ERROR: dependencies ‘rvest’, ‘xml2’ are not available for package ‘tidyverse’
    * removing ‘/opt/microsoft/ropen/3.5.3/lib64/R/library/tidyverse’
    
    下载的程序包在
    	‘/tmp/Rtmp0oAdDA/downloaded_packages’里
    更新'.Library'里的HTML程序包列表
    Making 'packages.html' ... 做完了。
    Warning messages:
    1: In install.packages("tidyverse") :
      安装程序包‘xml2’时退出狀態的值不是0
    2: In install.packages("tidyverse") :
      安装程序包‘rvest’时退出狀態的值不是0
    3: In install.packages("tidyverse") :
      安装程序包‘tidyverse’时退出狀態的值不是0
    ```
    
    - It means the lib path does not include the configuring files ( in this case "libicui18n.so.58") the package needs. And the procedure ended abruptly.
    
    ```bash
    locate libicui18n.so.58 #To find where the file is.
    
    ```
    
    - Result:
    
    ```bash
    /public/home/Huanga/miniconda3/envs/R3.4/lib/libicui18n.so.58
    /public/home/Huanga/miniconda3/envs/R3.4/lib/libicui18n.so.58.2
    ```
    
    - Add to lib path (in .bashrc):
    
    ```bash
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/public/home/Huanga/miniconda3/envs/R3.4/lib/
    ```
    
    - source .bashrc
    - Now we can install the package sucessfully.